<?php

namespace App;

/**
Application Configuration
**/
class Config
{

	const DB_HOST = 'localhost';

	const DB_NAME = 'private_instapp';

	const DB_USER = 'private_t0x1c350';

	const DB_PASSWORD = 'Insta350-@@';
	
	//const SITE_PATH = 'http://23.94.160.8';
	const SITE_PATH = 'http://web.innovinstas.com';
	
	//const SITE_ROOT = '/var/www/html/public';
	const SITE_ROOT = '/home1/private/public_html/instapp/fct1/public';

	const SHOW_ERRORS = false;
}

?>
