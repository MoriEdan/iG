<?php

namespace Core;

use PDO;
use App\Config;

/**
	Base Model
**/

abstract class Model
{

	/**
		Get the PDO database connection
	**/
	protected function getDB() {

		$db = null;

		if($db === null) {

			try {

				$dsn = 'mysql:host='.Config::DB_HOST.';dbname='.Config::DB_NAME.';charset=utf8';

				$db = new PDO($dsn, Config::DB_USER, Config::DB_PASSWORD);

				// Throw an Exception when an error occurs
				$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

				return $db;

			} catch (PDOException $e) {
				echo $e->getMessage();
			}
		}
	}
}

?>
